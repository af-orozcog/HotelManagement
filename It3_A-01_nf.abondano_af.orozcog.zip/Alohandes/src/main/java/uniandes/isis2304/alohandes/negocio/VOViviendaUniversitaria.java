package uniandes.isis2304.alohandes.negocio;

public interface VOViviendaUniversitaria extends VOOperador{

}
