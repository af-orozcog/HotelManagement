En la carpeta data se encuentra la carpeta SQL Instalación. Dentro esta el archivo SQL comandosCreacion, los cuales deben
correrse para crear las tablas. De igual forma se encuentra el archivo borrar para borrarlas. 
Finalmente también se encuentra sql poblamiento, el cuál es necesario correr para poblar la base de datos