--- datos de clientes
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (1, 'Amber', 'aramshaw0@squidoo.com', '269-691-2672', '0069-1340', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (2, 'Nicholle', 'nphin1@go.com', '848-224-6570', '54868-5551', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (3, 'Gwenore', 'gleveret2@thetimes.co.uk', '935-383-7007', '10147-0881', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (4, 'Pernell', 'pdannell3@mashable.com', '537-167-0191', '57883-404', 'ESTUDIANTE');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (5, 'Karia', 'kmouatt4@europa.eu', '933-462-8860', '64942-1151', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (6, 'Jaine', 'jparley5@bbc.co.uk', '822-126-1486', '25021-601', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (7, 'Brook', 'btuffrey6@over-blog.com', '406-922-0594', '50804-001', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (8, 'Mireille', 'msydenham7@google.cn', '627-811-1012', '55301-020', 'EMPLEADO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (9, 'Greggory', 'ghatfull8@surveymonkey.com', '263-467-5559', '43419-001', 'PROFESOR');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (10, 'Marysa', 'mjodkowski9@indiegogo.com', '267-365-8879', '0942-6309', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (11, 'Nolly', 'ntourrya@goodreads.com', '280-252-2676', '31722-537', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (12, 'Jami', 'jcodb@xinhuanet.com', '322-886-3947', '64679-907', 'PROFESOR');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (13, 'Mae', 'mhackeltonc@skype.com', '608-745-8323', '0536-3387', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (14, 'Holmes', 'hforrestd@sogou.com', '815-362-9058', '42192-115', 'NO_RELACIONADO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (15, 'Melisande', 'myurkiewicze@un.org', '184-305-7696', '30142-154', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (16, 'Adda', 'adoryf@tinypic.com', '972-194-6042', '54868-4556', 'NO_RELACIONADO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (17, 'Griff', 'gsotworthg@homestead.com', '690-276-5900', '53808-0551', 'EMPLEADO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (18, 'Claudio', 'cselleyh@smugmug.com', '698-881-9201', '49702-221', 'ESTUDIANTE');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (19, 'Sheba', 'sbywatersi@deviantart.com', '119-191-1598', '52125-709', 'NO_RELACIONADO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (20, 'Bren', 'broddaj@godaddy.com', '507-198-1506', '21695-866', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (21, 'Nike', 'nbecerilk@cisco.com', '407-847-4058', '59667-0101', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (22, 'Jeth', 'jcolstonl@360.cn', '964-145-9050', '55714-2216', 'NO_RELACIONADO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (23, 'Alasteir', 'aclineckm@php.net', '508-934-9156', '59900-110', 'NO_RELACIONADO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (24, 'Glenna', 'ghortopn@wordpress.org', '500-931-3095', '0519-1171', 'ESTUDIANTE');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (25, 'Keenan', 'kgeanyo@narod.ru', '679-602-5002', '0574-0153', 'NO_RELACIONADO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (26, 'Giulietta', 'ggouldebyp@newsvine.com', '429-831-9149', '60429-081', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (27, 'Agnella', 'achottyq@diigo.com', '605-888-0867', '0591-3196', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (28, 'Ray', 'rbernardinir@wikispaces.com', '548-443-8561', '76439-209', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (29, 'Sullivan', 'sguilayns@cnn.com', '414-791-8079', '55910-159', 'NO_RELACIONADO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (30, 'Alvis', 'aniast@telegraph.co.uk', '594-441-2629', '60681-1002', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (31, 'Vinny', 'vfromeu@archive.org', '793-906-8018', '48951-7107', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (32, 'Bartholomeo', 'bmillarv@wired.com', '857-921-2669', '36987-2067', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (33, 'Alidia', 'amortelw@mediafire.com', '718-271-1274', '31722-334', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (34, 'Haroun', 'hrainfordx@google.es', '471-719-4208', '41268-358', 'NO_RELACIONADO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (35, 'Darnall', 'dwhitseyy@issuu.com', '671-835-9188', '0944-4212', 'PADRE');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (36, 'Consalve', 'cbonnesenz@google.de', '252-127-2061', '0280-2610', 'PADRE');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (37, 'Paola', 'ptreneman10@yellowbook.com', '197-166-1610', '49349-891', 'ESTUDIANTE');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (38, 'Tallulah', 'tkulas11@nhs.uk', '423-738-1118', '67475-211', 'NO_RELACIONADO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (39, 'Celia', 'cmattaser12@naver.com', '198-308-1443', '68462-305', 'VECINO');
insert into CLIENTE (id, nombre, email, numero, documento, tipo_cliente) values (40, 'Eugene', 'ejephcott13@bandcamp.com', '219-658-9341', '59148-019', 'VECINO');


--- datos de los operadores
insert into OPERADOR (id, nombre, email, numero, tipo_operador) values (1, 'Camila', 'cpulver0@springer.com', '213-802-8305', 'PERSONA_NATURAL');
insert into OPERADOR (id, nombre, email, numero, tipo_operador) values (2, 'Rubie', 'rjoddins1@sciencedirect.com', '842-874-7025', 'PERSONA_NATURAL');
insert into OPERADOR (id, nombre, email, numero, tipo_operador) values (3, 'Damon', 'dsolway2@constantcontact.com', '602-201-7037', 'PERSONA_NATURAL');
insert into OPERADOR (id, nombre, email, numero, tipo_operador) values (4, 'Salem', 'sgravells3@acquirethisname.com', '112-159-3032', 'PERSONA_NATURAL');
insert into OPERADOR (id, nombre, email, numero, tipo_operador) values (5, 'Sammy', 'sjefferson4@umn.edu', '130-791-0129', 'PERSONA_NATURAL');
insert into OPERADOR (id, nombre, email, numero, tipo_operador) values (6, 'Carlye', 'cbruckshaw5@studiopress.com', '701-563-4064', 'HOTELERIA');
insert into OPERADOR (id, nombre, email, numero, tipo_operador) values (7, 'Edithe', 'ecoot6@moonfruit.com', '586-928-0187', 'VIVIENDA_UNIVERSITARIA');
insert into OPERADOR (id, nombre, email, numero, tipo_operador) values (8, 'Dione', 'dkinahan7@opensource.org', '815-511-3178', 'PERSONA_NATURAL');
insert into OPERADOR (id, nombre, email, numero, tipo_operador) values (9, 'Malina', 'mmactague8@trellian.com', '172-186-5989', 'VIVIENDA_UNIVERSITARIA');
insert into OPERADOR (id, nombre, email, numero, tipo_operador) values (10, 'Tana', 'twetwood9@nih.gov', '107-803-2239', 'HOTELERIA');


--- datos de las personas naturales
insert into PERSONA_NATURAL (id, DOCUMENTO, TIPO_PERSONA) values (1, '10191-1203', 'VECINO');
insert into PERSONA_NATURAL (id, DOCUMENTO, TIPO_PERSONA) values (2, '0007-3230', 'VECINO');
insert into PERSONA_NATURAL (id, DOCUMENTO, TIPO_PERSONA) values (3, '55045-1173', 'VECINO');
insert into PERSONA_NATURAL (id, DOCUMENTO, TIPO_PERSONA) values (4, '63830-855', 'VECINO');
insert into PERSONA_NATURAL (id, DOCUMENTO, TIPO_PERSONA) values (5, '36987-3187', 'PADRE');
insert into PERSONA_NATURAL (id, DOCUMENTO, TIPO_PERSONA) values (8, '0869-0370', 'PROFESOR');

--- datos de hoteles
insert into HOTELERIA (id, TIPO_HOTELERIA, HORA_APERTURA, HORA_CIERRE) values (6, 'HOSTAL', timestamp '2020-02-02 06:14:00', timestamp '2020-02-02 18:14:00');
insert into HOTELERIA (id, TIPO_HOTELERIA) values (10, 'HOTEL');



---datos de los servicios
insert into SERVICIO (id, NOMBRE, COSTO) values (1, 'Piscina', 93);
insert into SERVICIO (id, NOMBRE, COSTO) values (2, 'Television', 7);
insert into SERVICIO (id, NOMBRE, COSTO) values (3, 'Tennis de mesa', 94);
insert into SERVICIO (id, NOMBRE, COSTO) values (4, 'Canchas multideporte', 57);
insert into SERVICIO (id, NOMBRE, COSTO) values (5, 'Cocina', 91);
insert into SERVICIO (id, NOMBRE, COSTO) values (6, 'Cocineta', 61);
insert into SERVICIO (id, NOMBRE, COSTO) values (7, 'servicio a la habitacion', 86);
insert into SERVICIO (id, NOMBRE, COSTO) values (8, 'Energia', 60);
insert into SERVICIO (id, NOMBRE, COSTO) values (9, 'Agua', 89);
insert into SERVICIO (id, NOMBRE, COSTO) values (10, 'Gas', 10);

--- datos de las viviendas
insert into VIVIENDA (id, DIRECCION, CUPOS, OPERADOR,TIPO) values (1, '63948 Vahlen Hill', 5, 1,'HABITACION');
insert into VIVIENDA (id, DIRECCION, CUPOS, OPERADOR,TIPO) values (2, '16182 Vernon Avenue', 3, 2,'HABITACION');
insert into VIVIENDA (id, DIRECCION, CUPOS, OPERADOR,TIPO) values (3, '8911 Cordelia Court', 4, 3,'HABITACION');
insert into VIVIENDA (id, DIRECCION, CUPOS, OPERADOR,TIPO) values (4, '6929 Autumn Leaf Junction', 4, 4,'ESPORADICO');
insert into VIVIENDA (id, DIRECCION, CUPOS, OPERADOR,TIPO) values (5, '65868 Cardinal Hill', 4, 5,'CUARTO');
insert into VIVIENDA (id, DIRECCION, CUPOS, OPERADOR,TIPO) values (6, '7 Prairieview Junction', 4, 6, 'CUARTO');
insert into VIVIENDA (id, DIRECCION, CUPOS, OPERADOR,TIPO) values (7, '518 Meadow Valley Point', 4, 7, 'CUARTO');
insert into VIVIENDA (id, DIRECCION, CUPOS, OPERADOR,TIPO) values (8, '12 Manley Park', 3, 8, 'APARTAMENTO');
insert into VIVIENDA (id, DIRECCION, CUPOS, OPERADOR,TIPO) values (9, '884 Springs Park', 3, 9, 'APARTAMENTO');
insert into VIVIENDA (id, DIRECCION, CUPOS, OPERADOR,TIPO) values (10, '51662 Red Cloud Road', 5, 10, 'APARTAMENTO');

---(timestamp '2020-02-02 06:14:00', (timestamp '2020-02-02 18:14:00'
--- datos de las ofertas
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (1, 1, 'MESES', 1, timestamp '2014-07-01 06:14:00', timestamp '2021-07-02 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (2, 2, 'SEMESTRES', 1, timestamp '2020-02-02 06:14:00', timestamp '2021-07-03 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (3, 3, 'SEMESTRES', 1,timestamp '2020-02-02 06:14:00', timestamp '2021-07-04 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (4, 4, 'SEMESTRES', 1, timestamp '2020-02-02 06:14:00', timestamp '2021-07-05 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (5, 5, 'SEMESTRES', 2, timestamp '2020-02-02 06:14:00', timestamp '2021-07-06 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (6, 6, 'DIAS', 2, timestamp '2020-02-02 06:14:00', timestamp '2021-07-07 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (7, 7, 'SEMESTRES', 2, timestamp '2020-02-02 06:14:00', timestamp '2021-07-08 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (8, 8, 'SEMESTRES', 2, timestamp '2020-02-02 06:14:00', timestamp '2021-07-09 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (9, 9, 'MESES', 2, timestamp '2020-02-02 06:14:00', timestamp '2021-07-10 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (10, 10, 'DIAS', 3, timestamp '2020-02-02 06:14:00', timestamp '2021-07-11 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (11, 11, 'SEMESTRES', 3, timestamp '2020-02-02 06:14:00', timestamp '2021-07-12 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (12, 12, 'SEMESTRES', 3, timestamp '2020-02-02 06:14:00', timestamp '2021-07-13 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (13, 13, 'SEMESTRES', 3, timestamp '2020-02-02 06:14:00', timestamp '2021-07-14 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (14, 14, 'DIAS', 4, timestamp '2020-02-02 06:14:00', timestamp '2021-07-15 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (15, 15, 'MESES', 4, timestamp '2020-02-02 06:14:00', timestamp '2021-07-16 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (16, 16, 'SEMESTRES', 4, timestamp '2020-02-02 06:14:00', timestamp '2021-07-17 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (17, 17, 'DIAS', 4, timestamp '2020-02-02 06:14:00', timestamp '2021-07-18 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (18, 18, 'SEMESTRES', 5, timestamp '2020-02-02 06:14:00', timestamp '2021-07-19 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (19, 19, 'SEMESTRES', 5, timestamp '2020-02-02 06:14:00', timestamp '2021-07-20 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (20, 20, 'SEMESTRES', 5, timestamp '2020-02-02 06:14:00', timestamp '2021-07-21 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (21, 21, 'SEMESTRES', 5, timestamp '2020-02-02 06:14:00', timestamp '2021-07-22 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (22, 22, 'SEMESTRES', 6, timestamp '2020-02-02 06:14:00', timestamp '2021-07-23 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (23, 23, 'SEMESTRES', 6, timestamp '2020-02-02 06:14:00', timestamp '2021-07-24 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (24, 24, 'MESES', 6, timestamp '2020-02-02 06:14:00', timestamp '2021-07-25 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (25, 25, 'MESES', 6, timestamp '2020-02-02 06:14:00', timestamp '2021-07-26 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (26, 26, 'SEMESTRES', 7, timestamp '2020-02-02 06:14:00', timestamp '2021-07-27 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (27, 27, 'SEMESTRES', 7, timestamp '2020-02-02 06:14:00', timestamp '2021-07-28 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (28, 28, 'SEMESTRES', 7, timestamp '2020-02-02 06:14:00', timestamp '2021-07-29 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (29, 29, 'MESES', 7, timestamp '2020-02-02 06:14:00', timestamp '2021-07-30 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (30, 30, 'MESES', 8, timestamp '2020-02-02 06:14:00', timestamp '2021-07-31 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (31, 31, 'DIAS', 8, timestamp '2020-02-02 06:14:00', timestamp '2021-08-01 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (32, 32, 'SEMESTRES', 8, timestamp '2020-02-02 06:14:00', timestamp '2021-08-02 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (33, 33, 'SEMESTRES', 8, timestamp '2020-02-02 06:14:00', timestamp '2021-08-03 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (34, 34, 'MESES', 9, timestamp '2020-02-02 06:14:00', timestamp '2021-08-04 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (35, 35, 'SEMESTRES', 9, timestamp '2020-02-02 06:14:00', timestamp '2021-08-05 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (36, 36, 'MESES', 9, timestamp '2020-02-02 06:14:00', timestamp '2021-08-06 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (37, 37, 'SEMESTRES', 9, timestamp '2020-02-02 06:14:00', timestamp '2021-08-07 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (38, 38, 'SEMESTRES', 10, timestamp '2020-02-02 06:14:00', timestamp '2021-08-08 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (39, 39, 'SEMESTRES', 10, timestamp '2020-02-02 06:14:00', timestamp '2021-08-09 18:14:00',1);
insert into OFERTA (id, PRECIO, PERIODO, VIVIENDA, FECHAINICIO, FECHAFIN, HABILITADA) values (40, 40, 'SEMESTRES', 10, timestamp '2020-02-02 06:14:00', timestamp '2021-08-10 18:14:00',1);

--- datos de incluye
insert into INCLUYE (OFERTA, SERVICIO, INCLUIDO) values (35, 10, 1);
insert into INCLUYE (OFERTA, SERVICIO, INCLUIDO) values (32, 2, 0);
insert into INCLUYE (OFERTA, SERVICIO, INCLUIDO) values (25, 1, 1);
insert into INCLUYE (OFERTA, SERVICIO, INCLUIDO) values (40, 6, 0);
insert into INCLUYE (OFERTA, SERVICIO, INCLUIDO) values (27, 10, 0);
insert into INCLUYE (OFERTA, SERVICIO, INCLUIDO) values (35, 3, 1);
insert into INCLUYE (OFERTA, SERVICIO, INCLUIDO) values (15, 3, 0);
insert into INCLUYE (OFERTA, SERVICIO, INCLUIDO) values (15, 4, 0);
insert into INCLUYE (OFERTA, SERVICIO, INCLUIDO) values (23, 2, 0);
insert into INCLUYE (OFERTA, SERVICIO, INCLUIDO) values (16, 6, 1);
insert into INCLUYE (OFERTA, SERVICIO, INCLUIDO) values (1, 9, 1);
insert into INCLUYE (OFERTA, SERVICIO, INCLUIDO) values (31, 8, 1);

--- datos de habitaciones
insert into HABITACION (ID, TIPO_HABITACION, CATEGORIA, NUMERO) values (1, 'SUITE', 'ukbvrccraawfvw', 2);
insert into HABITACION (ID, TIPO_HABITACION, CATEGORIA, NUMERO) values (2, 'SEMISUITE', 'znxwypukzznnzr', 4);
insert into HABITACION (ID, TIPO_HABITACION, CATEGORIA, NUMERO) values (3, 'SUITE', 'qqemolelepggbn', 1);

--- datos de los seguro
insert into SEGURO (ID, EMPRESA, MONTO, INICIO_SEGURO, FIN_SEGURO) values (1, 'Meetz', 565, timestamp '2020-02-02 06:14:00', timestamp '2020-04-04 18:14:00');

--- datos de esporadico
insert into ESPORADICO (ID, AREA, AMOBLADO, NUMERO_HABITACIONES, NOCHES_ANIO, SEGURO) values (4, 7, 1, 4, 4, 1);

--- datos de cuartos
insert into CUARTO (ID, BANIO_PRIVADO, CUARTO_PRIVADO, ESQUEMA, MENAJE) values (5, 1, 0, 'ukhxnxcd', 'pqvwzpom');
insert into CUARTO (ID, BANIO_PRIVADO, CUARTO_PRIVADO, ESQUEMA, MENAJE) values (6, 0, 1, 'uryussls', 'wnygktrm');
insert into CUARTO (ID, BANIO_PRIVADO, CUARTO_PRIVADO, ESQUEMA, MENAJE) values (7, 1, 0, 'gmzbfvdx', 'vngxauwg');

--- datos de apartamentos
insert into APARTAMENTO (ID, AREA, AMOBLADO, NUMERO_HABITACIONES) values (8, 70, 1, 4);
insert into APARTAMENTO (ID, AREA, AMOBLADO, NUMERO_HABITACIONES) values (9, 50, 0, 1);
insert into APARTAMENTO (ID, AREA, AMOBLADO, NUMERO_HABITACIONES) values (10, 15, 0, 2);

--- datos de reservas
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (1, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 24, 38);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (2, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 16, 36);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (3, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 5, 23);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (4, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 5, 36);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (5, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 19, 32);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (6, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 4, 23);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (7, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 34, 13);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (8, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 30, 27);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (9, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 11, 16);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (10, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 28, 33);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (11, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 13, 1);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (12, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 2, 34);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (13, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 21, 2);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (14, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 19, 18);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (15, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 8, 29);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (16, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 9, 39);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (17, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 22, 16);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (18, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 16, 37);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (19, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 19, 12);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (20, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 2, 9);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (21, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 13, 10);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (22, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 26, 28);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (23, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 37, 27);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (24, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 30, 3);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (25, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 34, 25);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (26, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 40, 19);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (27, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 26, 18);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (28, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 36, 10);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (29, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 3, 5);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (30, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 18, 13);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (31, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 9, 34);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (32, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 28, 12);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (33, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 13, 5);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (34, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 24, 39);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (35, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 14, 32);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (36, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 1, 15);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (37, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 32, 6);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (38, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 7, 26);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (39, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 27, 29);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (40, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 16, 12);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (41, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 3, 27);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (42, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 3, 10);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (43, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 7, 4);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (44, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 28, 30);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (45, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 22, 3);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (46, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 6, 15);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (47, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 14, 31);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (48, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 2, 36);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (49, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 23, 17);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (50, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 17, 22);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (51, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 25, 6);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (52, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 15, 16);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (53, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 34, 8);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (54, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 24, 30);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (55, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 9, 6);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (56, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 7, 19);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (57, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 6, 18);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (58, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 30, 6);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (59, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 26, 34);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (60, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 7, 24);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (61, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 18, 22);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (62, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 5, 22);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (63, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 26, 23);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (64, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 28, 19);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (65, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 33, 24);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (66, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 32, 11);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (67, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 19, 5);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (68, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 13, 8);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (69, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 7, 26);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (70, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 18, 3);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (71, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 15, 26);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (72, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 10, 30);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (73, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 34, 40);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (74, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'MESES', 32, 14);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (75, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 13, 19);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (76, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 35, 10);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (77, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 19, 40);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (78, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'DIAS', 7, 17);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (79, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 29, 23);
insert into RESERVA (ID, INICIO, FIN, PERIODO_ARRENDAMIENTO, OFERTA, CLIENTE) values (80, timestamp '2020-02-02 06:14:00',timestamp '2020-04-04 18:14:00', 'SEMESTRES', 37, 40);

-- datos de ganancias
insert into GANANCIAS (ID, CANTIDAD, FECHA, OPERADOR) values (1, 10100, timestamp '2020-02-02 01:01:01', 1);
insert into GANANCIAS (ID, CANTIDAD, FECHA, OPERADOR) values (2, 10200, timestamp  '2020-02-02 01:01:01', 2);
insert into GANANCIAS (ID, CANTIDAD, FECHA, OPERADOR) values (3, 10300, timestamp '2020-02-02 01:01:01', 3);
insert into GANANCIAS (ID, CANTIDAD, FECHA, OPERADOR) values (4, 10400, timestamp '2020-02-02 01:01:01', 4);
insert into GANANCIAS (ID, CANTIDAD, FECHA, OPERADOR) values (5, 10500, timestamp '2020-02-02 01:01:01', 5);
insert into GANANCIAS (ID, CANTIDAD, FECHA, OPERADOR) values (6, 10600, timestamp '2020-02-02 01:01:01', 6);
insert into GANANCIAS (ID, CANTIDAD, FECHA, OPERADOR) values (7, 10700, timestamp '2020-02-02 01:01:01', 7);
insert into GANANCIAS (ID, CANTIDAD, FECHA, OPERADOR) values (8, 10800, timestamp '2020-02-02 01:01:01', 8);
insert into GANANCIAS (ID, CANTIDAD, FECHA, OPERADOR) values (9, 10900, timestamp '2020-02-02 01:01:01', 9);
insert into GANANCIAS (ID, CANTIDAD, FECHA, OPERADOR) values (10, 11000, timestamp '2020-02-02 01:01:01', 10);
commit;