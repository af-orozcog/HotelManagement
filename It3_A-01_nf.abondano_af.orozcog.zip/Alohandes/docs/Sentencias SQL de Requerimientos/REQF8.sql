--Selecciona las reservas pertenecientes
SELECT * FROM RESERVA WHERE colectiva = ?
--Elimina todas las reservas
DELETE FROM RESERVA WHERE id = ?
--Elimina la reserva colectiva
DELETE FROM RESERVA WHERE id = ?