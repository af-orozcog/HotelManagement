SELECT SUM(cantidad) 
FROM GANANCIAS 
WHERE operador =  AND ((año = ? AND mes >= ) OR (año = ? AND mes <= ));


SELECT  SUM(cantidad) 
FROM GANANCIAS WHERE operador =  AND año = ;